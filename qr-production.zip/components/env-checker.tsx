"use client"

export function EnvChecker() {
  // Simplified component with no environment variable checking
  return null
}
